"use client";
import { useState, useEffect, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { searchTools } from "@/lib/tools";
import ToolCard from "@/components/ToolCard";
import ToolDetail from "@/components/ToolDetail";

function SearchContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const q = searchParams.get("q") || "";

  const [query, setQuery] = useState(q);
  const [filter, setFilter] = useState("all");
  const [results, setResults] = useState([]);
  const [selected, setSelected] = useState(null);
  const [sort, setSort] = useState("rating");

  useEffect(() => {
    setQuery(q);
    const res = searchTools(q, filter);
    const sorted = [...res].sort((a, b) => {
      if (sort === "rating") return b.rating - a.rating;
      if (sort === "users") return parseInt(b.users) - parseInt(a.users);
      if (sort === "name") return a.name.localeCompare(b.name);
      return 0;
    });
    setResults(sorted);
    setSelected(null);
  }, [q, filter, sort]);

  function handleSearch() {
    if (!query.trim()) return;
    router.push(`/search?q=${encodeURIComponent(query.trim())}`);
  }

  const FILTERS = ["all", "free", "ai", "website", "app"];

  return (
    <div style={{ minHeight: "100vh", background: "#f8f7ff" }}>
      {/* Top bar */}
      <header style={{ background: "#fff", borderBottom: "1px solid #e5e3f5", padding: "12px 24px", display: "flex", alignItems: "center", gap: 16, position: "sticky", top: 0, zIndex: 20 }}>
        <div onClick={() => router.push("/")} style={{ display: "flex", alignItems: "center", gap: 6, cursor: "pointer", flexShrink: 0 }}>
          <div style={{ width: 28, height: 28, borderRadius: 8, background: "#7F77DD", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 14 }}>✦</div>
          <span style={{ fontWeight: 700, fontSize: 16, color: "#1a1a2e" }}>FindMyTool</span>
        </div>
        <div style={{ flex: 1, display: "flex", alignItems: "center", background: "#f8f7ff", border: "1.5px solid #e5e3f5", borderRadius: 30, padding: "8px 16px", gap: 8 }}>
          <span style={{ color: "#7F77DD" }}>🔍</span>
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSearch()}
            style={{ flex: 1, border: "none", background: "transparent", fontSize: 15, color: "#1a1a2e", outline: "none" }}
            placeholder="Search tools..."
          />
          {query && <span onClick={() => { setQuery(""); router.push("/search?q="); }} style={{ cursor: "pointer", color: "#999" }}>✕</span>}
        </div>
        <button onClick={handleSearch} style={{ background: "#7F77DD", color: "#fff", border: "none", borderRadius: 20, padding: "8px 18px", fontWeight: 600, fontSize: 14, cursor: "pointer" }}>Search</button>
      </header>

      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "24px 16px", display: "grid", gridTemplateColumns: selected ? "1fr 380px" : "1fr", gap: 24 }}>
        <div>
          {/* Filters + sort */}
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16, flexWrap: "wrap", gap: 10 }}>
            <div style={{ display: "flex", gap: 8 }}>
              {FILTERS.map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  style={{
                    padding: "6px 14px", borderRadius: 20, fontSize: 13, fontWeight: 500, cursor: "pointer", border: "none",
                    background: filter === f ? "#7F77DD" : "#fff",
                    color: filter === f ? "#fff" : "#666",
                    border: filter === f ? "none" : "1px solid #e5e3f5"
                  }}
                >
                  {f === "all" ? "All" : f === "ai" ? "AI Tools" : f.charAt(0).toUpperCase() + f.slice(1)}
                </button>
              ))}
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, color: "#666" }}>
              <span>Sort:</span>
              <select value={sort} onChange={(e) => setSort(e.target.value)} style={{ border: "1px solid #e5e3f5", borderRadius: 8, padding: "4px 8px", fontSize: 13, background: "#fff", color: "#444", outline: "none" }}>
                <option value="rating">Top Rated</option>
                <option value="users">Most Users</option>
                <option value="name">A–Z</option>
              </select>
            </div>
          </div>

          {/* Results count */}
          <p style={{ fontSize: 13, color: "#999", marginBottom: 14 }}>
            {results.length} tool{results.length !== 1 ? "s" : ""} found {q ? `for "${q}"` : ""}
          </p>

          {/* Cards */}
          {results.length === 0 ? (
            <div style={{ textAlign: "center", padding: "60px 20px", color: "#999" }}>
              <div style={{ fontSize: 48, marginBottom: 12 }}>🔍</div>
              <p style={{ fontSize: 16, fontWeight: 500, color: "#555", marginBottom: 8 }}>No tools found</p>
              <p style={{ fontSize: 14 }}>Try a different search term</p>
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {results.map((tool) => (
                <ToolCard
                  key={tool.id}
                  tool={tool}
                  selected={selected?.id === tool.id}
                  onClick={() => setSelected(selected?.id === tool.id ? null : tool)}
                />
              ))}
            </div>
          )}
        </div>

        {/* Detail panel */}
        {selected && (
          <div style={{ position: "sticky", top: 80, height: "fit-content" }}>
            <ToolDetail tool={selected} onClose={() => setSelected(null)} />
          </div>
        )}
      </div>
    </div>
  );
}

export default function SearchPage() {
  return (
    <Suspense fallback={<div style={{ padding: 40, textAlign: "center", color: "#999" }}>Loading...</div>}>
      <SearchContent />
    </Suspense>
  );
}
