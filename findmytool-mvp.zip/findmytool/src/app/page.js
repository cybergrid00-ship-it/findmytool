"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

const SUGGESTIONS = [
  "free AI video editor",
  "background remover",
  "AI writing assistant",
  "website builder",
  "project management",
  "AI image generator",
  "grammar checker",
  "design tool",
];

const CATEGORIES = [
  { label: "Video Editing", icon: "🎬", q: "video editing" },
  { label: "AI Writing", icon: "✍️", q: "AI writing assistant" },
  { label: "Image Generation", icon: "🎨", q: "AI image generator" },
  { label: "Design Tools", icon: "🖌️", q: "design tool" },
  { label: "Productivity", icon: "🚀", q: "project management" },
  { label: "Website Builder", icon: "🌐", q: "website builder" },
];

export default function Home() {
  const [query, setQuery] = useState("");
  const [focused, setFocused] = useState(false);
  const router = useRouter();

  function handleSearch(q) {
    const term = (q || query).trim();
    if (!term) return;
    router.push(`/search?q=${encodeURIComponent(term)}`);
  }

  function handleKey(e) {
    if (e.key === "Enter") handleSearch();
  }

  const filtered = SUGGESTIONS.filter((s) =>
    query ? s.toLowerCase().includes(query.toLowerCase()) : true
  ).slice(0, 6);

  return (
    <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column" }}>
      {/* Header */}
      <header style={{ padding: "20px 24px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div style={{ width: 32, height: 32, borderRadius: 10, background: "#7F77DD", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 16 }}>✦</div>
          <span style={{ fontWeight: 600, fontSize: 18, color: "#1a1a2e" }}>FindMyTool</span>
        </div>
        <nav style={{ display: "flex", gap: 24, fontSize: 14, color: "#666" }}>
          <span style={{ cursor: "pointer" }} onClick={() => router.push("/search?q=popular")}>Browse</span>
          <span style={{ cursor: "pointer", color: "#7F77DD", fontWeight: 500 }}>Submit a tool</span>
        </nav>
      </header>

      {/* Hero */}
      <main style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "0 24px", marginTop: -60 }}>
        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <div style={{ fontSize: 13, fontWeight: 500, color: "#7F77DD", background: "#EEEDFE", padding: "4px 14px", borderRadius: 20, display: "inline-block", marginBottom: 16 }}>
            ✦ 1,000+ tools indexed
          </div>
          <h1 style={{ fontSize: "clamp(32px, 6vw, 52px)", fontWeight: 700, color: "#1a1a2e", lineHeight: 1.2, margin: "0 0 12px" }}>
            Find the perfect tool<br />
            <span style={{ color: "#7F77DD" }}>for anything you need</span>
          </h1>
          <p style={{ fontSize: 16, color: "#666", maxWidth: 480, margin: "0 auto" }}>
            Search AI tools, websites, and apps — with real details on pricing, users, ratings, and reviews.
          </p>
        </div>

        {/* Search Box */}
        <div style={{ width: "100%", maxWidth: 600, position: "relative" }}>
          <div style={{
            display: "flex", alignItems: "center",
            background: "#fff", border: focused ? "2px solid #7F77DD" : "2px solid #e5e3f5",
            borderRadius: 50, padding: "12px 20px", gap: 12,
            boxShadow: focused ? "0 4px 24px rgba(127,119,221,0.15)" : "0 2px 12px rgba(0,0,0,0.06)",
            transition: "all 0.2s"
          }}>
            <span style={{ fontSize: 20, color: "#7F77DD" }}>🔍</span>
            <input
              className="search-input"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={handleKey}
              onFocus={() => setFocused(true)}
              onBlur={() => setTimeout(() => setFocused(false), 150)}
              placeholder="Search for any tool, AI, or website..."
              style={{ flex: 1, border: "none", background: "transparent", fontSize: 16, color: "#1a1a2e" }}
              autoFocus
            />
            {query && (
              <button onClick={() => setQuery("")} style={{ background: "none", border: "none", cursor: "pointer", color: "#999", fontSize: 18 }}>✕</button>
            )}
            <button
              onClick={() => handleSearch()}
              style={{ background: "#7F77DD", color: "#fff", border: "none", borderRadius: 30, padding: "8px 22px", fontWeight: 600, fontSize: 15, cursor: "pointer", whiteSpace: "nowrap" }}
            >
              Search
            </button>
          </div>

          {/* Autocomplete */}
          {focused && query && (
            <div style={{ position: "absolute", top: "calc(100% + 8px)", left: 0, right: 0, background: "#fff", border: "1px solid #e5e3f5", borderRadius: 16, overflow: "hidden", boxShadow: "0 8px 24px rgba(0,0,0,0.08)", zIndex: 10 }}>
              {filtered.map((s) => (
                <div
                  key={s}
                  onMouseDown={() => handleSearch(s)}
                  style={{ padding: "12px 20px", cursor: "pointer", fontSize: 14, color: "#444", display: "flex", alignItems: "center", gap: 10 }}
                  onMouseEnter={(e) => e.currentTarget.style.background = "#f8f7ff"}
                  onMouseLeave={(e) => e.currentTarget.style.background = "transparent"}
                >
                  <span style={{ color: "#7F77DD" }}>🔍</span> {s}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Quick suggestions */}
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "center", marginTop: 16, maxWidth: 560 }}>
          {["free AI video editor", "background remover", "AI writing", "image generator", "website builder"].map((s) => (
            <button
              key={s}
              onClick={() => handleSearch(s)}
              style={{ padding: "6px 14px", borderRadius: 20, border: "1px solid #e5e3f5", background: "#fff", fontSize: 13, color: "#555", cursor: "pointer" }}
            >
              {s}
            </button>
          ))}
        </div>

        {/* Category grid */}
        <div style={{ marginTop: 64, width: "100%", maxWidth: 640 }}>
          <p style={{ textAlign: "center", fontSize: 13, color: "#999", marginBottom: 16, textTransform: "uppercase", letterSpacing: 1 }}>Browse by category</p>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))", gap: 12 }}>
            {CATEGORIES.map((c) => (
              <button
                key={c.label}
                onClick={() => handleSearch(c.q)}
                style={{ background: "#fff", border: "1px solid #e5e3f5", borderRadius: 14, padding: "16px 12px", cursor: "pointer", textAlign: "center", transition: "all 0.15s" }}
                onMouseEnter={(e) => { e.currentTarget.style.border = "1px solid #7F77DD"; e.currentTarget.style.background = "#f8f7ff"; }}
                onMouseLeave={(e) => { e.currentTarget.style.border = "1px solid #e5e3f5"; e.currentTarget.style.background = "#fff"; }}
              >
                <div style={{ fontSize: 28, marginBottom: 6 }}>{c.icon}</div>
                <div style={{ fontSize: 13, fontWeight: 500, color: "#1a1a2e" }}>{c.label}</div>
              </button>
            ))}
          </div>
        </div>
      </main>

      <footer style={{ textAlign: "center", padding: "24px", fontSize: 13, color: "#aaa" }}>
        Built with ✦ by FindMyTool
      </footer>
    </div>
  );
}
