import "./globals.css";

export const metadata = {
  title: "FindMyTool — Discover the best tools & AI apps",
  description: "Search and find the best tools, AI apps, and websites for anything you need.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
