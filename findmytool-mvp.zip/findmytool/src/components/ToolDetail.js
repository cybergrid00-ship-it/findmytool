"use client";

const PRICING_COLORS = {
  Free: { bg: "#EAF3DE", color: "#27500A" },
  Freemium: { bg: "#E6F1FB", color: "#0C447C" },
  Paid: { bg: "#FAEEDA", color: "#633806" },
};

export default function ToolDetail({ tool, onClose }) {
  const pc = PRICING_COLORS[tool.pricing] || PRICING_COLORS.Freemium;
  const stars = Math.round(tool.rating);

  return (
    <div style={{ background: "#fff", border: "1px solid #e5e3f5", borderRadius: 20, overflow: "hidden" }}>
      {/* Header */}
      <div style={{ background: "#7F77DD", padding: "20px", color: "#fff" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{ width: 48, height: 48, borderRadius: 12, background: "rgba(255,255,255,0.2)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24 }}>
              {tool.type === "AI Tool" ? "🤖" : tool.type === "App" ? "📱" : "🌐"}
            </div>
            <div>
              <div style={{ fontWeight: 700, fontSize: 18 }}>{tool.name}</div>
              <div style={{ fontSize: 12, opacity: 0.8, marginTop: 2 }}>{tool.company} · {tool.founded}</div>
            </div>
          </div>
          <button onClick={onClose} style={{ background: "rgba(255,255,255,0.2)", border: "none", color: "#fff", borderRadius: 8, width: 28, height: 28, cursor: "pointer", fontSize: 16, display: "flex", alignItems: "center", justifyContent: "center" }}>✕</button>
        </div>

        {/* Quick stats */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginTop: 16 }}>
          {[
            { label: "Users", value: tool.users },
            { label: "Rating", value: tool.rating.toFixed(1) + " ★" },
            { label: "Pricing", value: tool.pricing },
          ].map((s) => (
            <div key={s.label} style={{ background: "rgba(255,255,255,0.15)", borderRadius: 10, padding: "8px 10px", textAlign: "center" }}>
              <div style={{ fontSize: 11, opacity: 0.75, marginBottom: 2 }}>{s.label}</div>
              <div style={{ fontSize: 14, fontWeight: 700 }}>{s.value}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding: "20px", display: "flex", flexDirection: "column", gap: 20 }}>
        {/* Description */}
        <div>
          <h3 style={{ fontSize: 13, fontWeight: 600, color: "#aaa", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 8 }}>About</h3>
          <p style={{ fontSize: 14, color: "#444", lineHeight: 1.7 }}>{tool.longDescription}</p>
        </div>

        {/* Platforms */}
        <div>
          <h3 style={{ fontSize: 13, fontWeight: 600, color: "#aaa", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 8 }}>Available on</h3>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
            {tool.platforms.map((p) => (
              <span key={p} style={{ fontSize: 12, color: "#7F77DD", background: "#EEEDFE", padding: "4px 10px", borderRadius: 8, fontWeight: 500 }}>{p}</span>
            ))}
          </div>
        </div>

        {/* Star rating breakdown */}
        <div>
          <h3 style={{ fontSize: 13, fontWeight: 600, color: "#aaa", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 10 }}>Rating breakdown</h3>
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12 }}>
            <div style={{ fontSize: 36, fontWeight: 700, color: "#1a1a2e" }}>{tool.rating.toFixed(1)}</div>
            <div>
              <div style={{ fontSize: 20, color: "#EF9F27" }}>{"★".repeat(stars)}{"☆".repeat(5 - stars)}</div>
              <div style={{ fontSize: 12, color: "#aaa" }}>Based on community reviews</div>
            </div>
          </div>
          {[5, 4, 3, 2, 1].map((n) => {
            const pct = n === stars ? 65 : n === stars - 1 ? 22 : n === stars + 1 ? 8 : 3;
            return (
              <div key={n} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 5 }}>
                <span style={{ fontSize: 12, color: "#888", width: 12 }}>{n}</span>
                <span style={{ color: "#EF9F27", fontSize: 12 }}>★</span>
                <div style={{ flex: 1, height: 6, background: "#f0f0f0", borderRadius: 4 }}>
                  <div style={{ width: pct + "%", height: "100%", background: "#EF9F27", borderRadius: 4 }}></div>
                </div>
                <span style={{ fontSize: 12, color: "#aaa", width: 28 }}>{pct}%</span>
              </div>
            );
          })}
        </div>

        {/* Pros & Cons */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          <div style={{ background: "#f0faf5", borderRadius: 12, padding: 12 }}>
            <h3 style={{ fontSize: 13, fontWeight: 600, color: "#27500A", marginBottom: 8 }}>Pros</h3>
            {tool.pros.map((p) => (
              <div key={p} style={{ display: "flex", gap: 6, alignItems: "flex-start", marginBottom: 6 }}>
                <span style={{ color: "#1D9E75", fontSize: 13, marginTop: 1 }}>✓</span>
                <span style={{ fontSize: 13, color: "#444", lineHeight: 1.4 }}>{p}</span>
              </div>
            ))}
          </div>
          <div style={{ background: "#fff8f5", borderRadius: 12, padding: 12 }}>
            <h3 style={{ fontSize: 13, fontWeight: 600, color: "#633806", marginBottom: 8 }}>Cons</h3>
            {tool.cons.map((c) => (
              <div key={c} style={{ display: "flex", gap: 6, alignItems: "flex-start", marginBottom: 6 }}>
                <span style={{ color: "#D85A30", fontSize: 13, marginTop: 1 }}>✕</span>
                <span style={{ fontSize: 13, color: "#444", lineHeight: 1.4 }}>{c}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Highlights */}
        <div>
          <h3 style={{ fontSize: 13, fontWeight: 600, color: "#aaa", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 8 }}>Key features</h3>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
            {tool.highlights.map((h) => (
              <span key={h} style={{ fontSize: 13, background: "#f8f7ff", color: "#534AB7", padding: "5px 12px", borderRadius: 8, border: "1px solid #EEEDFE" }}>{h}</span>
            ))}
          </div>
        </div>

        {/* Alternatives */}
        <div>
          <h3 style={{ fontSize: 13, fontWeight: 600, color: "#aaa", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 8 }}>Alternatives</h3>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
            {tool.alternatives.map((a) => (
              <span key={a} style={{ fontSize: 13, background: "#f8f7ff", color: "#555", padding: "5px 12px", borderRadius: 8, border: "1px solid #e5e3f5", cursor: "pointer" }}>{a}</span>
            ))}
          </div>
        </div>

        {/* CTA */}
        <a
          href={tool.url}
          target="_blank"
          rel="noopener noreferrer"
          style={{ display: "block", background: "#7F77DD", color: "#fff", textAlign: "center", padding: "13px", borderRadius: 12, fontWeight: 600, fontSize: 15, textDecoration: "none" }}
        >
          Visit {tool.name} ↗
        </a>
      </div>
    </div>
  );
}
