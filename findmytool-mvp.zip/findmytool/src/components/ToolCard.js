"use client";

const PRICING_COLORS = {
  Free: { bg: "#EAF3DE", color: "#27500A" },
  Freemium: { bg: "#E6F1FB", color: "#0C447C" },
  Paid: { bg: "#FAEEDA", color: "#633806" },
};

const TYPE_COLORS = {
  "AI Tool": "#7F77DD",
  Website: "#1D9E75",
  App: "#D85A30",
};

export default function ToolCard({ tool, selected, onClick }) {
  const pc = PRICING_COLORS[tool.pricing] || PRICING_COLORS.Freemium;
  const tc = TYPE_COLORS[tool.type] || "#888";
  const stars = Math.round(tool.rating);

  return (
    <div
      onClick={onClick}
      style={{
        background: "#fff",
        border: selected ? "2px solid #7F77DD" : "1px solid #e5e3f5",
        borderRadius: 16,
        padding: "16px 20px",
        cursor: "pointer",
        transition: "all 0.15s",
      }}
      onMouseEnter={(e) => { if (!selected) e.currentTarget.style.borderColor = "#c5c0f0"; }}
      onMouseLeave={(e) => { if (!selected) e.currentTarget.style.borderColor = "#e5e3f5"; }}
    >
      {/* Top row */}
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 12, marginBottom: 10 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 42, height: 42, borderRadius: 10, background: tc + "20", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20, flexShrink: 0 }}>
            {tool.type === "AI Tool" ? "🤖" : tool.type === "App" ? "📱" : "🌐"}
          </div>
          <div>
            <div style={{ fontWeight: 600, fontSize: 16, color: "#1a1a2e" }}>{tool.name}</div>
            <div style={{ fontSize: 12, color: "#888", marginTop: 2 }}>{tool.type} · {tool.category}</div>
          </div>
        </div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", justifyContent: "flex-end" }}>
          <span style={{ ...pc, padding: "3px 10px", borderRadius: 8, fontSize: 12, fontWeight: 600 }}>{tool.pricing}</span>
          {tool.badge && (
            <span style={{ background: tool.badge === "Popular" ? "#EEEDFE" : "#FBEAF0", color: tool.badge === "Popular" ? "#3C3489" : "#72243E", padding: "3px 10px", borderRadius: 8, fontSize: 12, fontWeight: 600 }}>
              {tool.badge}
            </span>
          )}
        </div>
      </div>

      {/* Description */}
      <p style={{ fontSize: 14, color: "#555", lineHeight: 1.6, marginBottom: 12 }}>{tool.description}</p>

      {/* Stats row */}
      <div style={{ display: "flex", gap: 20, marginBottom: 12, flexWrap: "wrap" }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
          <span style={{ fontSize: 11, color: "#aaa", textTransform: "uppercase", letterSpacing: 0.5 }}>Users</span>
          <span style={{ fontSize: 14, fontWeight: 600, color: "#1a1a2e" }}>{tool.users}</span>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
          <span style={{ fontSize: 11, color: "#aaa", textTransform: "uppercase", letterSpacing: 0.5 }}>Founded</span>
          <span style={{ fontSize: 14, fontWeight: 600, color: "#1a1a2e" }}>{tool.founded}</span>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
          <span style={{ fontSize: 11, color: "#aaa", textTransform: "uppercase", letterSpacing: 0.5 }}>Company</span>
          <span style={{ fontSize: 14, fontWeight: 600, color: "#1a1a2e" }}>{tool.company}</span>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
          <span style={{ fontSize: 11, color: "#aaa", textTransform: "uppercase", letterSpacing: 0.5 }}>Rating</span>
          <span style={{ fontSize: 14, fontWeight: 600, color: "#1a1a2e" }}>
            {"★".repeat(stars)}{"☆".repeat(5 - stars)} {tool.rating.toFixed(1)}
          </span>
        </div>
      </div>

      {/* Highlights */}
      <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 12 }}>
        {tool.highlights.map((h) => (
          <span key={h} style={{ fontSize: 12, background: "#f8f7ff", color: "#555", padding: "3px 10px", borderRadius: 8, border: "1px solid #e5e3f5" }}>{h}</span>
        ))}
      </div>

      {/* Platforms */}
      <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 12 }}>
        {tool.platforms.map((p) => (
          <span key={p} style={{ fontSize: 11, color: "#7F77DD", background: "#EEEDFE", padding: "2px 8px", borderRadius: 6, fontWeight: 500 }}>{p}</span>
        ))}
      </div>

      {/* Footer */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <span style={{ fontSize: 12, color: "#7F77DD", fontWeight: 500 }}>
          {selected ? "▲ Hide details" : "▼ View full details"}
        </span>
        <a
          href={tool.url}
          target="_blank"
          rel="noopener noreferrer"
          onClick={(e) => e.stopPropagation()}
          style={{ fontSize: 13, color: "#534AB7", border: "1px solid #AFA9EC", borderRadius: 8, padding: "5px 14px", textDecoration: "none", fontWeight: 500 }}
        >
          Visit ↗
        </a>
      </div>
    </div>
  );
}
